﻿Public Class Form2

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, d, i, f, g, h, j, k, l, m As Integer


        Fer.Bcompu1 = TextBox4.Text
        Fer.Bcompu2 = TextBox5.Text
        Fer.Bcompu3 = TextBox6.Text
        Fer.Bcompu4 = TextBox7.Text
        a = Fer.Bcompu1
        b = Fer.Bcompu2
        c = Fer.Bcompu3
        d = Fer.Bcompu4
        Fer.Bcompu = (a + b + c + d) / 4
        TextBox1.Text = Fer.Bcompu

        Andre.Lcompu1 = TextBox8.Text
        Andre.Lcompu2 = TextBox9.Text
        Andre.Lcompu3 = TextBox10.Text
        Andre.Lcompu4 = TextBox11.Text
        i = Andre.Lcompu1
        f = Andre.Lcompu2
        g = Andre.Lcompu3
        h = Andre.Lcompu4
        Andre.Lcompu = (i + f + g + h) / 4
        TextBox2.Text = Andre.Lcompu


        Gabi.Gcompu1 = TextBox12.Text
        Gabi.Gcompu2 = TextBox13.Text
        Gabi.Gcompu3 = TextBox14.Text
        Gabi.Gcompu4 = TextBox15.Text
        j = Gabi.Gcompu1
        k = Gabi.Gcompu2
        l = Gabi.Gcompu3
        m = Gabi.Gcompu4
        Gabi.Gcompu = (j + k + l + m) / 4
        TextBox3.Text = Gabi.Gcompu




    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class