﻿Public Class Form4
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Application.Exit()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c, d, i, f, g, h, j, k, l, m As Integer


        Fer.Bingles1 = TextBox4.Text
        Fer.Bingles2 = TextBox5.Text
        Fer.Bingles3 = TextBox6.Text
        Fer.Bingles4 = TextBox7.Text
        a = Fer.Bingles1
        b = Fer.Bingles2
        c = Fer.Bingles3
        d = Fer.Bingles4
        Fer.Bingles = (a + b + c + d) / 4
        TextBox1.Text = Fer.Bingles

        Andre.Lingles1 = TextBox8.Text
        Andre.Lingles2 = TextBox9.Text
        Andre.Lingles3 = TextBox10.Text
        Andre.Lingles4 = TextBox11.Text
        i = Andre.Lingles1
        f = Andre.Lingles2
        g = Andre.Lingles3
        h = Andre.Lingles4
        Andre.Lingles = (i + f + g + h) / 4
        TextBox2.Text = Andre.Lingles


        Gabi.Gingles1 = TextBox12.Text
        Gabi.Gingles2 = TextBox13.Text
        Gabi.Gingles3 = TextBox14.Text
        Gabi.Gingles4 = TextBox15.Text
        j = Gabi.Gingles1
        k = Gabi.Gingles2
        l = Gabi.Gingles3
        m = Gabi.Gingles4
        Gabi.Gingles = (j + k + l + m) / 4
        TextBox3.Text = Gabi.Gingles
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()
    End Sub
End Class